
<img class="logo" src="<?php echo e(asset('/images/logo/logo.png')); ?>" alt="EPTLM Logo">
<?php /**PATH /Applications/MAMP/htdocs/EPTLM_laravel/resources/views/partials/logo.blade.php ENDPATH**/ ?>