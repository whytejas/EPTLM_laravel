

<div class="form-group">
    <?php echo Form::label('Name', 'Name:'); ?>

    <?php echo Form::text('Name', null, ['class' => 'form-control']); ?>

</div>

<div class="form-group">
    <?php echo Form::label('Email', 'Email:'); ?>

    <?php echo Form::email('Email', null, ['class' => 'form-control']); ?>

</div>


<div class="form-group">
    <?php echo Form::label('Message', 'Message:'); ?>

    <?php echo Form::textarea('Message', null, ['class' => 'form-control']); ?>

</div>


<div class="form-group">
    <?php echo Form::submit('Submit', ['class' => 'submit btn btn-primary form-control']); ?>

</div>





<?php /**PATH /Applications/MAMP/htdocs/EPTLM_laravel/resources/views/form.blade.php ENDPATH**/ ?>