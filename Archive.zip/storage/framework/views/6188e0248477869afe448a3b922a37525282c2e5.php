<nav>

    <ul>
        <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
        <li><a href="<?php echo e(url('/about')); ?>">About Us</a></li>
        <li><a href="<?php echo e(url('/news')); ?>">News</a></li>
        <li><a href="<?php echo e(url('/volunteer')); ?>">Volunteer</a></li>
        <li><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>


    </ul>
</nav>
<?php /**PATH /Applications/MAMP/htdocs/EPTLM_laravel/resources/views/partials/nav.blade.php ENDPATH**/ ?>