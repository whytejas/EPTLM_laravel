<?php $__env->startSection('title', 'EPTLM: Home'); ?>
<?php $__env->startSection('content'); ?>





<div class="intro">

    <img  class="banner" src="<?php echo e(asset('/images/banner/flyer_v1.jpg')); ?>" alt="EPTLM Banner">

</div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/EPTLM_laravel/resources/views/main.blade.php ENDPATH**/ ?>