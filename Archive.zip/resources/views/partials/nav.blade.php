<nav>

    <ul>
        <li><a href="{{ url('/') }}">Home</a></li>
        <li><a href="{{ url('/about') }}">About Us</a></li>
        <li><a href="{{ url('/news') }}">News</a></li>
        <li><a href="{{ url('/volunteer') }}">Volunteer</a></li>
        <li><a href="{{ url('/contact') }}">Contact</a></li>


    </ul>
</nav>
