
<img class="logo" src="{{ asset('/images/logo/logo.png') }}" alt="EPTLM Logo">
