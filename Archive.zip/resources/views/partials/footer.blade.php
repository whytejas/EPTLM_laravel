<footer>


    <!--
    <div id="newsletter_form">
     <h1 class="signup_label">Subscribe To Get Email Updates</h1>
     <form action="signup.php" method="post">
      <p>
       <input type="text" name="user_name" id="user_name" placeholder="Enter Your Name">
       <input type="text" name="email" id="email" placeholder="Enter Your Email Id"/>
      </p>
      <input type="submit" value="Subscribe" name="submit_form"/>
      <input type="button" value="No Thanks" onclick="close_form();"/>
     </form>
    </div> -->

    <div>
        <a href="https://www.facebook.com/englishpourtoutlemonde/" class="fa fa-facebook"></a>
        <a href="https://twitter.com/eptlm" class="fa fa-twitter"></a>
        <a href="https://instagram.com/eptlm" class="fa fa-instagram"></a>

    </div>
    <div>

<span id="footer"><a href="{{url('/contact')}}">Contact Us</a><br>
© English Pour Tout Le Monde :  (EPTLM) 2019<br>

         <a href="{{url('/privacy')}}">Privacy Policy</a></span>

    </div>
</footer>
