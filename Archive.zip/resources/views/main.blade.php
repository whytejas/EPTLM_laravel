@extends('master')
@section('title', 'EPTLM: Home')
@section('content')





<div class="intro">

    <img  class="banner" src="{{ asset('/images/banner/flyer_v1.jpg') }}" alt="EPTLM Banner">

</div>


@stop



